package com.example.assiment01;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class randomCar extends AppCompatActivity implements AdapterView.OnItemSelectedListener  {
    ImageView image;
    Button buttonrandom;
    Random Rimage;
    Dialog mDialog;
    TextView textView;

    Integer[] images = {
            R.drawable.alfa,
            R.drawable.ascort,
            R.drawable.au,
            R.drawable.ben,
            R.drawable.bmw,
            R.drawable.buggati,
            R.drawable.cit,
            R.drawable.dec,
            R.drawable.deimler,
            R.drawable.ds,
            R.drawable.fiat,
            R.drawable.ford,
            R.drawable.honda,
            R.drawable.hyundai,
            R.drawable.jaguar,
            R.drawable.kia,
            R.drawable.lexus,
            R.drawable.mazda,
            R.drawable.mg,
            R.drawable.mitshubishi,
            R.drawable.nssan,
            R.drawable.peugeot,
            R.drawable.ren,
            R.drawable.seat,
            R.drawable.skoda,
            R.drawable.subaru,
            R.drawable.suzuki,
            R.drawable.toyota,
            R.drawable.vau,
            R.drawable.volksvagen,
            R.drawable.volvo,
            R.drawable.vox,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random_car);

        image =findViewById(R.id.imageView1);
        buttonrandom=findViewById(R.id.buttonRandom);
        Rimage = new Random();
        mDialog =new Dialog(this);



        Spinner spinner=findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,R.array.Car_Names, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        image.setImageResource(images[Rimage.nextInt(images.length)]);



    }



    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text1 = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(),text1,Toast.LENGTH_SHORT).show();
        switch (position){
            case 1:
               buttonrandom.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View v) {
                       if (1==R.drawable.bmw){
                           messageCorrect();

                       }
                       else{
                           messageWrong();

                       }
                   }
               });
                break;
            case 2:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (2==R.drawable.au){
                            messageCorrect();

                        }
                        else{
                            messageWrong();
                        }
                    }
                });

                break;
            case 3:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (3==R.drawable.ben){
                            messageCorrect();
                        }
                        else{
                            messageWrong();
                        }
                    }
                });

                break;
            case 4:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (4==R.drawable.toyota){
                            messageCorrect();
                        }
                        else{
                            messageWrong();
                        }
                    }
                });

                break;
            case 5:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (5==R.drawable.nssan){
                            messageCorrect();
                        }
                        else{
                            messageWrong();
                        }
                    }
                });

                break;
            case 6:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (6==R.drawable.volksvagen){
                            messageCorrect();
                        }
                        else{
                            messageWrong();
                        }
                    }
                });
                break;
            case 7:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (7==R.drawable.deimler){
                            messageCorrect();
                        }
                        else{
                            messageWrong();
                        }
                    }
                });
                break;
            case 8:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (8==R.drawable.ford){
                            messageCorrect();
                        }
                        else{
                            messageWrong();
                        }
                    }
                });
                break;
            case 9:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (9==R.drawable.buggati){
                            messageCorrect();
                        }
                        else{
                            messageWrong();
                        }
                    }
                });

                break;
            case 10:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (10==R.drawable.ascort){
                            messageCorrect();
                        }
                        else{
                            messageWrong();
                        }
                    }
                });


                break;
            case 11:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (11==R.drawable.mazda){

                        }
                        else{

                        }
                    }
                });


                break;
            case 12:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (12==R.drawable.kia){

                        }
                        else{

                        }
                    }
                });
                break;
            case 13:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (13==R.drawable.subaru){

                        }
                        else{

                        }
                    }
                });
                break;
            case 14:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (14==R.drawable.skoda){

                        }
                        else{

                        }
                    }
                });
                break;
            case 15:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (15==R.drawable.honda){

                        }
                        else{

                        }
                    }
                });

                break;
            case 16:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (16==R.drawable.peugeot){

                        }
                        else{

                        }
                    }
                });
                break;
            case 17:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (17==R.drawable.alfa){

                        }
                        else{

                        }
                    }
                });

                break;
            case 18:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (18==R.drawable.volvo){

                        }
                        else{

                        }
                    }
                });

                break;
            case 19:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (19==R.drawable.jaguar){

                        }
                        else{

                        }
                    }
                });
                break;
            case 20:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (20==R.drawable.hyundai){

                        }
                        else{

                        }
                    }
                });

                break;
            case 21:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (21==R.drawable.seat){

                        }
                        else{

                        }
                    }
                });

                break;
            case 22:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (22==R.drawable.ren){

                        }
                        else{

                        }
                    }
                });
                break;
            case 23:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (23==R.drawable.mitshubishi){

                        }
                        else{

                        }
                    }
                });
            case 24:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (24==R.drawable.suzuki){

                        }
                        else{

                        }
                    }
                });
                break;
            case 25:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (25==R.drawable.cit){

                        }
                        else{

                        }
                    }
                });
                break;
            case 26:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (26==R.drawable.mg){

                        }
                        else{

                        }
                    }
                });

                break;
            case 27:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (27==R.drawable.ds){

                        }
                        else{

                        }
                    }
                });
                break;
            case 28:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (28==R.drawable.fiat){

                        }
                        else{

                        }
                    }
                });
                break;
            case 29:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (29==R.drawable.vau){

                        }
                        else{

                        }
                    }
                });

                break;
            case 30:
                buttonrandom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (30==R.drawable.ford){

                        }
                        else{


                        }
                    }
                });
                break;
        }







    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void messageCorrect(){
        Context context = getApplicationContext();
        CharSequence text = "CORRECT";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }
    public void messageWrong(){
        Context context = getApplicationContext();
        CharSequence text = "WRONG";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }


}


