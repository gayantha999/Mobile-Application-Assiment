package com.example.assiment01;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class randomCar extends AppCompatActivity implements AdapterView.OnItemSelectedListener  {
    ImageView image;
    Button buttonrandom;
    Random Rimage;
    Dialog mDialog;
    int randomNumber;
    String text1;
    Integer[] images = {
            R.drawable.acura,
            R.drawable.audi,
            R.drawable.bently,
            R.drawable.benz,
            R.drawable.bmw,
            R.drawable.buick,
            R.drawable.cadillac,
            R.drawable.chevrolet,
            R.drawable.dodge,
            R.drawable.ferrari,
            R.drawable.ford,
            R.drawable.gm,
            R.drawable.gmc,
            R.drawable.honda,
            R.drawable.hyundai,
            R.drawable.jaguar,
            R.drawable.jeep,
            R.drawable.lambogini,
            R.drawable.land,
            R.drawable.lexus,
            R.drawable.lincoln,
            R.drawable.mazda,
            R.drawable.nissan,
            R.drawable.porsche,
            R.drawable.ram,
            R.drawable.subaru,
            R.drawable.tesla,
            R.drawable.toyota,
            R.drawable.vokvagen,
            R.drawable.volvo,

    };

    String [] CarNames;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random_car);

        Spinner spinner = findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.car_names, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);


            CarNames = getResources().getStringArray(R.array.car_names);

            image = findViewById(R.id.imageView1);
            buttonrandom = findViewById(R.id.buttonRandom);
            Rimage = new Random();
            mDialog = new Dialog(this);


            randomNumber = Rimage.nextInt(images.length);
            image.setImageResource(images[randomNumber]);


        }



    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        text1 = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(),text1,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void messageCorrect(){
        Context context = getApplicationContext();
        CharSequence text = "CORRECT";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        View view=toast.getView();
        view.setBackgroundColor(Color.GREEN);
        toast.show();
    }
    public void messageWrong(){
        Context context = getApplicationContext();
        CharSequence text = "WRONG";
        int duration = Toast.LENGTH_LONG;

        Toast toast = Toast.makeText(context, text, duration);
        View view=toast.getView();
        view.setBackgroundColor(Color.RED);
        toast.show();
    }

    public void buttonClick(View view) {
        if (text1.equals(CarNames[randomNumber])){
            messageCorrect();
            buttonrandom.setText("Next");


        }else{
            messageWrong();
        }
    }
}


